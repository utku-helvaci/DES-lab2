# Lab 2 - DES on Two Computers (CMPE455/CMSE456)

## Run on two machines (Docker)

```sh
docker compose up -d --build                          # start machine-a and machine-b
docker exec -it machine-b tcpServer                   # terminal 1: Machine B (server)
docker exec -it machine-a tcpClient -s 172.28.10.20   # terminal 2: Machine A (client)
docker compose --profile capture up sniffer           # optional: watch the packets on the LAN
docker compose down
```

The client sends first; then the two sides take turns. `:exit` (or Ctrl-D) ends the
conversation. Both sides need the same key: `-k <16 hex digits>` or `$DES_KEY`
(default: the textbook key `0f1571c947d9e859`). `-t` prints the full DES step table
for the first block of every message; `-m ecb` switches from CBC to ECB.

## DES step tables

```sh
bin/des_trace                         # textbook example: key 0f1571c947d9e859, P = 02468aceeca86420
bin/des_trace -s                      # + the 8 S-box look-ups of every round
bin/des_trace -f summary              # handout Table 4.2 layout (round, Ki, Li, Ri)
bin/des_trace -d -i da02ce3a89ecac3b  # decryption
bin/des_trace -f csv > trace.csv      # formats: table, csv, md, summary
bin/des_avalanche -P 4                # handout Table 4.3 (plaintext bit 4 flipped)
bin/des_avalanche -K 4                # Table 4.4 (key bit 4 flipped)
```

## Debugging

* **VS Code**: open this folder, choose *DES steps: textbook example* in *Run and Debug*
  (needs the C/C++ extension). Put breakpoints on the `return ...;` line of the step
  functions in `src/des.c` and add the parameter and the returned variable to *Watch*.
* **GDB**: `gdb -tui --args bin/des_trace -q`, then e.g. `break des_initial_permutation`,
  `run`, `next`, `display/z block`, `display/z permuted`.

## DOcker test 
./make demo
