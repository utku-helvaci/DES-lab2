| # | Round | Input | Method (C function) | Output | DES step (lab item) |
|--:|:-----:|-------|---------------------|--------|---------------------|
| 1 | - | `K = 0f1571c947d9e859` | `des_permuted_choice_1` | `C0 = 68fc44a, D0 = 1113e96` | 2.4.1 Permuted choice 1 (PC-1) |
| 2 | 1 | `C0 = 68fc44a, shift 1` | `des_left_circular_shift` | `C1 = d1f8894` | 2.4.2 Left circular shift of C |
| 3 | 1 | `D0 = 1113e96, shift 1` | `des_left_circular_shift` | `D1 = 2227d2c` | 2.4.2 Left circular shift of D |
| 4 | 1 | `C1D1 = d1f8894 2227d2c` | `des_permuted_choice_2` | `K1 = 7833c320da70` | 2.4.3 Permuted choice 2 (PC-2) |
| 5 | 2 | `C1 = d1f8894, shift 1` | `des_left_circular_shift` | `C2 = a3f1129` | 2.4.2 Left circular shift of C |
| 6 | 2 | `D1 = 2227d2c, shift 1` | `des_left_circular_shift` | `D2 = 444fa58` | 2.4.2 Left circular shift of D |
| 7 | 2 | `C2D2 = a3f1129 444fa58` | `des_permuted_choice_2` | `K2 = 2b1a74ca48d8` | 2.4.3 Permuted choice 2 (PC-2) |
| 8 | 3 | `C2 = a3f1129, shift 2` | `des_left_circular_shift` | `C3 = 8fc44a6` | 2.4.2 Left circular shift of C |
| 9 | 3 | `D2 = 444fa58, shift 2` | `des_left_circular_shift` | `D3 = 113e961` | 2.4.2 Left circular shift of D |
| 10 | 3 | `C3D3 = 8fc44a6 113e961` | `des_permuted_choice_2` | `K3 = 8c78d881d31d` | 2.4.3 Permuted choice 2 (PC-2) |
| 11 | 4 | `C3 = 8fc44a6, shift 2` | `des_left_circular_shift` | `C4 = 3f1129a` | 2.4.2 Left circular shift of C |
| 12 | 4 | `D3 = 113e961, shift 2` | `des_left_circular_shift` | `D4 = 44fa584` | 2.4.2 Left circular shift of D |
| 13 | 4 | `C4D4 = 3f1129a 44fa584` | `des_permuted_choice_2` | `K4 = 1667789316a0` | 2.4.3 Permuted choice 2 (PC-2) |
| 14 | 5 | `C4 = 3f1129a, shift 2` | `des_left_circular_shift` | `C5 = fc44a68` | 2.4.2 Left circular shift of C |
| 15 | 5 | `D4 = 44fa584, shift 2` | `des_left_circular_shift` | `D5 = 13e9611` | 2.4.2 Left circular shift of D |
| 16 | 5 | `C5D5 = fc44a68 13e9611` | `des_permuted_choice_2` | `K5 = ce5d01d80b25` | 2.4.3 Permuted choice 2 (PC-2) |
| 17 | 6 | `C5 = fc44a68, shift 2` | `des_left_circular_shift` | `C6 = f1129a3` | 2.4.2 Left circular shift of C |
| 18 | 6 | `D5 = 13e9611, shift 2` | `des_left_circular_shift` | `D6 = 4fa5844` | 2.4.2 Left circular shift of D |
| 19 | 6 | `C6D6 = f1129a3 4fa5844` | `des_permuted_choice_2` | `K6 = 4bab4d126a9c` | 2.4.3 Permuted choice 2 (PC-2) |
| 20 | 7 | `C6 = f1129a3, shift 2` | `des_left_circular_shift` | `C7 = c44a68f` | 2.4.2 Left circular shift of C |
| 21 | 7 | `D6 = 4fa5844, shift 2` | `des_left_circular_shift` | `D7 = 3e96111` | 2.4.2 Left circular shift of D |
| 22 | 7 | `C7D7 = c44a68f 3e96111` | `des_permuted_choice_2` | `K7 = 09f48b713191` | 2.4.3 Permuted choice 2 (PC-2) |
| 23 | 8 | `C7 = c44a68f, shift 2` | `des_left_circular_shift` | `C8 = 1129a3f` | 2.4.2 Left circular shift of C |
| 24 | 8 | `D7 = 3e96111, shift 2` | `des_left_circular_shift` | `D8 = fa58444` | 2.4.2 Left circular shift of D |
| 25 | 8 | `C8D8 = 1129a3f fa58444` | `des_permuted_choice_2` | `K8 = 710deaa3202b` | 2.4.3 Permuted choice 2 (PC-2) |
| 26 | 9 | `C8 = 1129a3f, shift 1` | `des_left_circular_shift` | `C9 = 225347e` | 2.4.2 Left circular shift of C |
| 27 | 9 | `D8 = fa58444, shift 1` | `des_left_circular_shift` | `D9 = f4b0889` | 2.4.2 Left circular shift of D |
| 28 | 9 | `C9D9 = 225347e f4b0889` | `des_permuted_choice_2` | `K9 = 129ab83347c3` | 2.4.3 Permuted choice 2 (PC-2) |
| 29 | 10 | `C9 = 225347e, shift 2` | `des_left_circular_shift` | `C10 = 894d1f8` | 2.4.2 Left circular shift of C |
| 30 | 10 | `D9 = f4b0889, shift 2` | `des_left_circular_shift` | `D10 = d2c2227` | 2.4.2 Left circular shift of D |
| 31 | 10 | `C10D10 = 894d1f8 d2c2227` | `des_permuted_choice_2` | `K10 = 9c38661e8103` | 2.4.3 Permuted choice 2 (PC-2) |
| 32 | 11 | `C10 = 894d1f8, shift 2` | `des_left_circular_shift` | `C11 = 25347e2` | 2.4.2 Left circular shift of C |
| 33 | 11 | `D10 = d2c2227, shift 2` | `des_left_circular_shift` | `D11 = 4b0889f` | 2.4.2 Left circular shift of D |
| 34 | 11 | `C11D11 = 25347e2 4b0889f` | `des_permuted_choice_2` | `K11 = a26e4cc66544` | 2.4.3 Permuted choice 2 (PC-2) |
| 35 | 12 | `C11 = 25347e2, shift 2` | `des_left_circular_shift` | `C12 = 94d1f88` | 2.4.2 Left circular shift of C |
| 36 | 12 | `D11 = 4b0889f, shift 2` | `des_left_circular_shift` | `D12 = 2c2227d` | 2.4.2 Left circular shift of D |
| 37 | 12 | `C12D12 = 94d1f88 2c2227d` | `des_permuted_choice_2` | `K12 = 48772468a3c8` | 2.4.3 Permuted choice 2 (PC-2) |
| 38 | 13 | `C12 = 94d1f88, shift 2` | `des_left_circular_shift` | `C13 = 5347e22` | 2.4.2 Left circular shift of C |
| 39 | 13 | `D12 = 2c2227d, shift 2` | `des_left_circular_shift` | `D13 = b0889f4` | 2.4.2 Left circular shift of D |
| 40 | 13 | `C13D13 = 5347e22 b0889f4` | `des_permuted_choice_2` | `K13 = c09d79f0d40b` | 2.4.3 Permuted choice 2 (PC-2) |
| 41 | 14 | `C13 = 5347e22, shift 2` | `des_left_circular_shift` | `C14 = 4d1f889` | 2.4.2 Left circular shift of C |
| 42 | 14 | `D13 = b0889f4, shift 2` | `des_left_circular_shift` | `D14 = c2227d2` | 2.4.2 Left circular shift of D |
| 43 | 14 | `C14D14 = 4d1f889 c2227d2` | `des_permuted_choice_2` | `K14 = c5e2634e162a` | 2.4.3 Permuted choice 2 (PC-2) |
| 44 | 15 | `C14 = 4d1f889, shift 2` | `des_left_circular_shift` | `C15 = 347e225` | 2.4.2 Left circular shift of C |
| 45 | 15 | `D14 = c2227d2, shift 2` | `des_left_circular_shift` | `D15 = 0889f4b` | 2.4.2 Left circular shift of D |
| 46 | 15 | `C15D15 = 347e225 0889f4b` | `des_permuted_choice_2` | `K15 = a3df829c7968` | 2.4.3 Permuted choice 2 (PC-2) |
| 47 | 16 | `C15 = 347e225, shift 1` | `des_left_circular_shift` | `C16 = 68fc44a` | 2.4.2 Left circular shift of C |
| 48 | 16 | `D15 = 0889f4b, shift 1` | `des_left_circular_shift` | `D16 = 1113e96` | 2.4.2 Left circular shift of D |
| 49 | 16 | `C16D16 = 68fc44a 1113e96` | `des_permuted_choice_2` | `K16 = a6120b4d4c25` | 2.4.3 Permuted choice 2 (PC-2) |
| 50 | - | `P = 02468aceeca86420` | `des_initial_permutation` | `L0 = 5a005a00, R0 = 3cf03c0f` | 2.1 Initial permutation (IP) |
| 51 | 1 | `R0 = 3cf03c0f` | `des_expansion_permutation` | `E(R0) = 9f97a01f805e` | 2.3 Expansion/permutation E |
| 52 | 1 | `E = 9f97a01f805e, K1 = 7833c320da70` | `des_xor_round_key` | `E^K1 = e7a4633f5a2e` | 2.5 XOR with round key |
| 53 | 1 | `E^K1 = e7a4633f5a2e` | `des_sbox_substitution` | `S = a32f11c2` | 2.6 S-boxes (48 -> 32 bits) |
| 54 | 1 | `S = a32f11c2` | `des_permutation_p` | `f(R0,K1) = e0d27245` | 2.7 Permutation P |
| 55 | 1 | `L0 = 5a005a00, f = e0d27245` | `des_xor_left_half` | `L0^f = bad22845` | 2.8 XOR with left half |
| 56 | 1 | `L0^f | R0 = bad22845 3cf03c0f` | `des_swap_halves` | `L1 | R1 = 3cf03c0f bad22845` | 2.9 Swap of the halves |
| 57 | 2 | `R1 = bad22845` | `des_expansion_permutation` | `E(R1) = df56a415020b` | 2.3 Expansion/permutation E |
| 58 | 2 | `E = df56a415020b, K2 = 2b1a74ca48d8` | `des_xor_round_key` | `E^K2 = f44cd0df4ad3` | 2.5 XOR with round key |
| 59 | 2 | `E^K2 = f44cd0df4ad3` | `des_sbox_substitution` | `S = 68f19445` | 2.6 S-boxes (48 -> 32 bits) |
| 60 | 2 | `S = 68f19445` | `des_permutation_p` | `f(R1,K2) = a5198b2c` | 2.7 Permutation P |
| 61 | 2 | `L1 = 3cf03c0f, f = a5198b2c` | `des_xor_left_half` | `L1^f = 99e9b723` | 2.8 XOR with left half |
| 62 | 2 | `L1^f | R1 = 99e9b723 bad22845` | `des_swap_halves` | `L2 | R2 = bad22845 99e9b723` | 2.9 Swap of the halves |
| 63 | 3 | `R2 = 99e9b723` | `des_expansion_permutation` | `E(R2) = cf3f53dae907` | 2.3 Expansion/permutation E |
| 64 | 3 | `E = cf3f53dae907, K3 = 8c78d881d31d` | `des_xor_round_key` | `E^K3 = 43478b5b3a1a` | 2.5 XOR with round key |
| 65 | 3 | `E^K3 = 43478b5b3a1a` | `des_sbox_substitution` | `S = 3c8ffec0` | 2.6 S-boxes (48 -> 32 bits) |
| 66 | 3 | `S = 3c8ffec0` | `des_permutation_p` | `f(R2,K3) = b17c13db` | 2.7 Permutation P |
| 67 | 3 | `L2 = bad22845, f = b17c13db` | `des_xor_left_half` | `L2^f = 0bae3b9e` | 2.8 XOR with left half |
| 68 | 3 | `L2^f | R2 = 0bae3b9e 99e9b723` | `des_swap_halves` | `L3 | R3 = 99e9b723 0bae3b9e` | 2.9 Swap of the halves |
| 69 | 4 | `R3 = 0bae3b9e` | `des_expansion_permutation` | `E(R3) = 057d5c1f7cfc` | 2.3 Expansion/permutation E |
| 70 | 4 | `E = 057d5c1f7cfc, K4 = 1667789316a0` | `des_xor_round_key` | `E^K4 = 131a248c6a5c` | 2.5 XOR with round key |
| 71 | 4 | `E^K4 = 131a248c6a5c` | `des_sbox_substitution` | `S = db898f1c` | 2.6 S-boxes (48 -> 32 bits) |
| 72 | 4 | `S = db898f1c` | `des_permutation_p` | `f(R3,K4) = dba8e16a` | 2.7 Permutation P |
| 73 | 4 | `L3 = 99e9b723, f = dba8e16a` | `des_xor_left_half` | `L3^f = 42415649` | 2.8 XOR with left half |
| 74 | 4 | `L3^f | R3 = 42415649 0bae3b9e` | `des_swap_halves` | `L4 | R4 = 0bae3b9e 42415649` | 2.9 Swap of the halves |
| 75 | 5 | `R4 = 42415649` | `des_expansion_permutation` | `E(R4) = a04202aac252` | 2.3 Expansion/permutation E |
| 76 | 5 | `E = a04202aac252, K5 = ce5d01d80b25` | `des_xor_round_key` | `E^K5 = 6e1f0372c977` | 2.5 XOR with round key |
| 77 | 5 | `E^K5 = 6e1f0372c977` | `des_sbox_substitution` | `S = 5de8ecd0` | 2.6 S-boxes (48 -> 32 bits) |
| 78 | 5 | `S = 5de8ecd0` | `des_permutation_p` | `f(R4,K5) = 131dc1df` | 2.7 Permutation P |
| 79 | 5 | `L4 = 0bae3b9e, f = 131dc1df` | `des_xor_left_half` | `L4^f = 18b3fa41` | 2.8 XOR with left half |
| 80 | 5 | `L4^f | R4 = 18b3fa41 42415649` | `des_swap_halves` | `L5 | R5 = 42415649 18b3fa41` | 2.9 Swap of the halves |
| 81 | 6 | `R5 = 18b3fa41` | `des_expansion_permutation` | `E(R5) = 8f15a7ff4202` | 2.3 Expansion/permutation E |
| 82 | 6 | `E = 8f15a7ff4202, K6 = 4bab4d126a9c` | `des_xor_round_key` | `E^K6 = c4beeaed289e` | 2.5 XOR with round key |
| 83 | 6 | `E^K6 = c4beeaed289e` | `des_sbox_substitution` | `S = 525b4d47` | 2.6 S-boxes (48 -> 32 bits) |
| 84 | 6 | `S = 525b4d47` | `des_permutation_p` | `f(R5,K6) = d457a86a` | 2.7 Permutation P |
| 85 | 6 | `L5 = 42415649, f = d457a86a` | `des_xor_left_half` | `L5^f = 9616fe23` | 2.8 XOR with left half |
| 86 | 6 | `L5^f | R5 = 9616fe23 18b3fa41` | `des_swap_halves` | `L6 | R6 = 18b3fa41 9616fe23` | 2.9 Swap of the halves |
| 87 | 7 | `R6 = 9616fe23` | `des_expansion_permutation` | `E(R6) = cac0ad7fc107` | 2.3 Expansion/permutation E |
| 88 | 7 | `E = cac0ad7fc107, K7 = 09f48b713191` | `des_xor_round_key` | `E^K7 = c334260ef096` | 2.5 XOR with round key |
| 89 | 7 | `E^K7 = c334260ef096` | `des_sbox_substitution` | `S = f610babe` | 2.6 S-boxes (48 -> 32 bits) |
| 90 | 7 | `S = f610babe` | `des_permutation_p` | `f(R6,K7) = 7fa286b3` | 2.7 Permutation P |
| 91 | 7 | `L6 = 18b3fa41, f = 7fa286b3` | `des_xor_left_half` | `L6^f = 67117cf2` | 2.8 XOR with left half |
| 92 | 7 | `L6^f | R6 = 67117cf2 9616fe23` | `des_swap_halves` | `L7 | R7 = 9616fe23 67117cf2` | 2.9 Swap of the halves |
| 93 | 8 | `R7 = 67117cf2` | `des_expansion_permutation` | `E(R7) = 30e8a2bf97a4` | 2.3 Expansion/permutation E |
| 94 | 8 | `E = 30e8a2bf97a4, K8 = 710deaa3202b` | `des_xor_round_key` | `E^K8 = 41e5481cb78f` | 2.5 XOR with round key |
| 95 | 8 | `E^K8 = 41e5481cb78f` | `des_sbox_substitution` | `S = 3a50cc14` | 2.6 S-boxes (48 -> 32 bits) |
| 96 | 8 | `S = 3a50cc14` | `des_permutation_p` | `f(R7,K8) = 570d022a` | 2.7 Permutation P |
| 97 | 8 | `L7 = 9616fe23, f = 570d022a` | `des_xor_left_half` | `L7^f = c11bfc09` | 2.8 XOR with left half |
| 98 | 8 | `L7^f | R7 = c11bfc09 67117cf2` | `des_swap_halves` | `L8 | R8 = 67117cf2 c11bfc09` | 2.9 Swap of the halves |
| 99 | 9 | `R8 = c11bfc09` | `des_expansion_permutation` | `E(R8) = e028f7ff8053` | 2.3 Expansion/permutation E |
| 100 | 9 | `E = e028f7ff8053, K9 = 129ab83347c3` | `des_xor_round_key` | `E^K9 = f2b24fccc790` | 2.5 XOR with round key |
| 101 | 9 | `E^K9 = f2b24fccc790` | `des_sbox_substitution` | `S = 5f33f61a` | 2.6 S-boxes (48 -> 32 bits) |
| 102 | 9 | `S = 5f33f61a` | `des_permutation_p` | `f(R8,K9) = ef6ec09e` | 2.7 Permutation P |
| 103 | 9 | `L8 = 67117cf2, f = ef6ec09e` | `des_xor_left_half` | `L8^f = 887fbc6c` | 2.8 XOR with left half |
| 104 | 9 | `L8^f | R8 = 887fbc6c c11bfc09` | `des_swap_halves` | `L9 | R9 = c11bfc09 887fbc6c` | 2.9 Swap of the halves |
| 105 | 10 | `R9 = 887fbc6c` | `des_expansion_permutation` | `E(R9) = 4503ffdf8359` | 2.3 Expansion/permutation E |
| 106 | 10 | `E = 4503ffdf8359, K10 = 9c38661e8103` | `des_xor_round_key` | `E^K10 = d93b99c1025a` | 2.5 XOR with round key |
| 107 | 10 | `E^K10 = d93b99c1025a` | `des_sbox_substitution` | `S = 7001f040` | 2.6 S-boxes (48 -> 32 bits) |
| 108 | 10 | `S = 7001f040` | `des_permutation_p` | `f(R9,K10) = a1148282` | 2.7 Permutation P |
| 109 | 10 | `L9 = c11bfc09, f = a1148282` | `des_xor_left_half` | `L9^f = 600f7e8b` | 2.8 XOR with left half |
| 110 | 10 | `L9^f | R9 = 600f7e8b 887fbc6c` | `des_swap_halves` | `L10 | R10 = 887fbc6c 600f7e8b` | 2.9 Swap of the halves |
| 111 | 11 | `R10 = 600f7e8b` | `des_expansion_permutation` | `E(R10) = b0005ebfd456` | 2.3 Expansion/permutation E |
| 112 | 11 | `E = b0005ebfd456, K11 = a26e4cc66544` | `des_xor_round_key` | `E^K11 = 126e1279b112` | 2.5 XOR with round key |
| 113 | 11 | `E^K11 = 126e1279b112` | `des_sbox_substitution` | `S = db529b29` | 2.6 S-boxes (48 -> 32 bits) |
| 114 | 11 | `S = db529b29` | `des_permutation_p` | `f(R10,K11) = 7de9ec02` | 2.7 Permutation P |
| 115 | 11 | `L10 = 887fbc6c, f = 7de9ec02` | `des_xor_left_half` | `L10^f = f596506e` | 2.8 XOR with left half |
| 116 | 11 | `L10^f | R10 = f596506e 600f7e8b` | `des_swap_halves` | `L11 | R11 = 600f7e8b f596506e` | 2.9 Swap of the halves |
| 117 | 12 | `R11 = f596506e` | `des_expansion_permutation` | `E(R11) = 7abcac2a035d` | 2.3 Expansion/permutation E |
| 118 | 12 | `E = 7abcac2a035d, K12 = 48772468a3c8` | `des_xor_round_key` | `E^K12 = 32cb8842a095` | 2.5 XOR with round key |
| 119 | 12 | `E^K12 = 32cb8842a095` | `des_sbox_substitution` | `S = bd0088b6` | 2.6 S-boxes (48 -> 32 bits) |
| 120 | 12 | `S = bd0088b6` | `des_permutation_p` | `f(R11,K12) = 138a4633` | 2.7 Permutation P |
| 121 | 12 | `L11 = 600f7e8b, f = 138a4633` | `des_xor_left_half` | `L11^f = 738538b8` | 2.8 XOR with left half |
| 122 | 12 | `L11^f | R11 = 738538b8 f596506e` | `des_swap_halves` | `L12 | R12 = f596506e 738538b8` | 2.9 Swap of the halves |
| 123 | 13 | `R12 = 738538b8` | `des_expansion_permutation` | `E(R12) = 3a7c0a9f15f0` | 2.3 Expansion/permutation E |
| 124 | 13 | `E = 3a7c0a9f15f0, K13 = c09d79f0d40b` | `des_xor_round_key` | `E^K13 = fae1736fc1fb` | 2.5 XOR with round key |
| 125 | 13 | `E^K13 = fae1736fc1fb` | `des_sbox_substitution` | `S = 01049b75` | 2.6 S-boxes (48 -> 32 bits) |
| 126 | 13 | `S = 01049b75` | `des_permutation_p` | `f(R12,K13) = 33307c20` | 2.7 Permutation P |
| 127 | 13 | `L12 = f596506e, f = 33307c20` | `des_xor_left_half` | `L12^f = c6a62c4e` | 2.8 XOR with left half |
| 128 | 13 | `L12^f | R12 = c6a62c4e 738538b8` | `des_swap_halves` | `L13 | R13 = 738538b8 c6a62c4e` | 2.9 Swap of the halves |
| 129 | 14 | `R13 = c6a62c4e` | `des_expansion_permutation` | `E(R13) = 60d50c15825d` | 2.3 Expansion/permutation E |
| 130 | 14 | `E = 60d50c15825d, K14 = c5e2634e162a` | `des_xor_round_key` | `E^K14 = a5376f5b9477` | 2.5 XOR with round key |
| 131 | 14 | `E^K14 = a5376f5b9477` | `des_sbox_substitution` | `S = 40f8f6e0` | 2.6 S-boxes (48 -> 32 bits) |
| 132 | 14 | `S = 40f8f6e0` | `des_permutation_p` | `f(R13,K14) = 253585cd` | 2.7 Permutation P |
| 133 | 14 | `L13 = 738538b8, f = 253585cd` | `des_xor_left_half` | `L13^f = 56b0bd75` | 2.8 XOR with left half |
| 134 | 14 | `L13^f | R13 = 56b0bd75 c6a62c4e` | `des_swap_halves` | `L14 | R14 = c6a62c4e 56b0bd75` | 2.9 Swap of the halves |
| 135 | 15 | `R14 = 56b0bd75` | `des_expansion_permutation` | `E(R14) = aad5a15fabaa` | 2.3 Expansion/permutation E |
| 136 | 15 | `E = aad5a15fabaa, K15 = a3df829c7968` | `des_xor_round_key` | `E^K15 = 090a23c3d2c2` | 2.5 XOR with round key |
| 137 | 15 | `E^K15 = 090a23c3d2c2` | `des_sbox_substitution` | `S = 498ff892` | 2.6 S-boxes (48 -> 32 bits) |
| 138 | 15 | `S = 498ff892` | `des_permutation_p` | `f(R14,K15) = b34ed1c1` | 2.7 Permutation P |
| 139 | 15 | `L14 = c6a62c4e, f = b34ed1c1` | `des_xor_left_half` | `L14^f = 75e8fd8f` | 2.8 XOR with left half |
| 140 | 15 | `L14^f | R14 = 75e8fd8f 56b0bd75` | `des_swap_halves` | `L15 | R15 = 56b0bd75 75e8fd8f` | 2.9 Swap of the halves |
| 141 | 16 | `R15 = 75e8fd8f` | `des_expansion_permutation` | `E(R15) = babf517fbc5e` | 2.3 Expansion/permutation E |
| 142 | 16 | `E = babf517fbc5e, K16 = a6120b4d4c25` | `des_xor_round_key` | `E^K16 = 1cad5a32f07b` | 2.5 XOR with round key |
| 143 | 16 | `E^K16 = 1cad5a32f07b` | `des_sbox_substitution` | `S = 4becbad5` | 2.6 S-boxes (48 -> 32 bits) |
| 144 | 16 | `S = 4becbad5` | `des_permutation_p` | `f(R15,K16) = 7339d9e5` | 2.7 Permutation P |
| 145 | 16 | `L15 = 56b0bd75, f = 7339d9e5` | `des_xor_left_half` | `L15^f = 25896490` | 2.8 XOR with left half |
| 146 | 16 | `L15^f | R15 = 25896490 75e8fd8f` | `des_swap_halves` | `L16 | R16 = 75e8fd8f 25896490` | 2.9 Swap of the halves |
| 147 | - | `L16 | R16 = 75e8fd8f 25896490` | `des_swap_halves` | `R16 | L16 = 25896490 75e8fd8f` | 2.9 32-bit swap after round 16 |
| 148 | - | `R16 | L16 = 25896490 75e8fd8f` | `des_inverse_initial_permutation` | `C = da02ce3a89ecac3b` | 2.2 Inverse initial perm. IP^-1 |
